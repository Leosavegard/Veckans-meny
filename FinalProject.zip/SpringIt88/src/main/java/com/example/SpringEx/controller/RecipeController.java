

package com.example.SpringEx.controller;

import com.example.SpringEx.dao.service.IngredientService;
import com.example.SpringEx.dao.service.RecipeService;
import com.example.SpringEx.model.Ingredient;
import com.example.SpringEx.model.Recipe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

@Controller
@SessionAttributes("recepy")

public class RecipeController {

    Integer id;
    boolean newRecepy;
    @Autowired
    RecipeService recipeService;

    @Autowired
    IngredientService ingredientService;

    @GetMapping("/recipes")
    public String findAll(Model model, String keyword, String showMostPopular) {

        List<Recipe> recipes = recipeService.findAll();

        if (keyword != null) {
            model.addAttribute("recipeList", recipeService.findByKeyword(keyword));

        } else if (showMostPopular != null) {
            model.addAttribute("recipeList", recipeService.findAllOrderByLike());

        }else  {
            recipes = recipeService.findAll();
            model.addAttribute("recipeList", recipes);
        }
        return "recipes";
    }




    @GetMapping("/cancel")
    public String returnToMainPage(Model model, String keyword) {

        if (newRecepy) {
            recipeService.deleteById(id);
            newRecepy = false;
        }

        List<Recipe> recipes = recipeService.findAll();

        if (keyword != null) {
            model.addAttribute("recipeList", recipeService.findByKeyword(keyword));
        } else {
            recipes = recipeService.findAll();
            model.addAttribute("recipeList", recipes);
        }
        return "recipes";
    }

    @GetMapping("/cancel/2")
    public String returnToMainPage2(Model model, String keyword) {

        return "redirect:/recipes";
    }


    @GetMapping("/recipe/new")
    public String showAddRecipe(Model model) {
        newRecepy = true;
        Recipe r = new Recipe("");
        Recipe recepy = recipeService.save(r);
        id = recepy.getId();

        List<Ingredient> ingredients = ingredientService.findAll();

        model.addAttribute("ingredients", ingredients);
        model.addAttribute("recepy", r);
        model.addAttribute("ingredient", new Ingredient());

        model.addAttribute("pageTitle", "Add New Recipe");


        return "recipe_form";
    }

    @GetMapping("/recipe/new/ingredient")
    public String showAddIngredient(Model model, Recipe recepy) {

        model.addAttribute("ingredient", new Ingredient());
        model.addAttribute("recepy", recepy);
        return "ingredient_form";
    }


    @PostMapping("/recipes/save")
    public String saveRecipe(Recipe recepy, RedirectAttributes ra, SessionStatus status) {

        recipeService.save(recepy);

        ra.addFlashAttribute("message", "The recipe has been saved Succesfully!");
        status.isComplete();
        newRecepy = false;
        return "redirect:/recipes";
    }

    @PostMapping("/manage/save/ingredient2")
    public String saveIngredient2(Ingredient ingredient, Model model) {

        ingredientService.save(ingredient);
        return showEditForm(id, model);

    }

    @PostMapping("/manage/save/ingredient")
    public String saveIngredient(Ingredient ingredient, Model model) {

        ingredientService.save(ingredient);
        model.addAttribute("ingredients", ingredientService.findAll());
        model.addAttribute("pageTitle", "Add New Recipe");

        return "recipe_form";
    }

    @GetMapping("/recipe/edit/{id}")
    public String showEditForm(@PathVariable("id") Integer id, Model model) {
        this.id = id;
        Recipe r = recipeService.get(id);

        List<Ingredient> ingredients = ingredientService.findAll();
        List<Boolean> selected = new ArrayList<>(Collections.nCopies(ingredients.size(), false));

        model.addAttribute("ingredients", ingredients);
        model.addAttribute("ingredient", new Ingredient());
        model.addAttribute("recepy", r);
        if (newRecepy == true)
            model.addAttribute("pageTitle", "New Recipe");
        else
            model.addAttribute("pageTitle", "Edit Recipe");

        return "recipe_form";

    }

    @GetMapping("/recipe/delete/{id}")
    public String deleteDish(@PathVariable("id") Integer id) {
        recipeService.deleteById(id);
        return "redirect:/recipes";
    }

    @GetMapping("/recipes/like/{id}")
    public String likeRecipe(@PathVariable("id") Integer id) {

        Recipe recipe = recipeService.get(id);
        int likeCount = recipe.getLike();
        recipe.setLike(++likeCount);

        recipeService.save(recipe);
        return "redirect:/recipes";
    }

    @GetMapping("/recipe/random")
    public String randomRecipes(Model model) {

        List<Recipe> recipes = recipeService.getRandomRecipes();

        model.addAttribute("recipes", recipes);

        List<Ingredient> ingredients = recipeService.ingredientList(recipes);

        model.addAttribute("ingredients", ingredients);

        return "random_recipes";


    }

    @GetMapping("/recipe/random/veg")
    public String randomVegRecipes(Model model) {

        List<Recipe> recipes = recipeService.getRandomVegRecipes();

        model.addAttribute("recipes", recipes);

        List<Ingredient> ingredients = recipeService.ingredientList(recipes);

        model.addAttribute("ingredients", ingredients);

        return "random_recipes_veg";


    }



}


