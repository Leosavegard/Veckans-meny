package com.example.SpringEx.dao.service;


import com.example.SpringEx.dao.IngredientRepository;
import com.example.SpringEx.model.Ingredient;
import com.example.SpringEx.model.Recipe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


@Service
public class IngredientService {

    @Autowired
    IngredientRepository ingredientRepository;

    public List<Ingredient> findAll() {
        return (List<Ingredient>) ingredientRepository.findAll();
    }

    public Optional<Ingredient> findById(Integer id) {
        return ingredientRepository.findById(id);
    }

    public void save(Ingredient ingredient) {
        ingredientRepository.save(ingredient);
    }

}
