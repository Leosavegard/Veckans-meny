package com.example.SpringEx.dao.service;

import com.example.SpringEx.dao.IngredientRepository;
import com.example.SpringEx.dao.RecipeRepository;
import com.example.SpringEx.model.Ingredient;
import com.example.SpringEx.model.Recipe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;

@Service
public class RecipeService {

    @PersistenceContext
    private EntityManager entityManager;

    @Lazy
    @Autowired
    RecipeRepository repository;

    @Autowired
    IngredientRepository ingredientRepository;



    @GetMapping()
    public List<Recipe> findAll() {
        List<Recipe> recipes = (List<Recipe>) repository.findAll();
        return recipes;
    }


    public Recipe save(Recipe recipe) {
        return repository.save(recipe);
    }

    public void deleteById(Integer dishId) {
        Recipe recipe = repository.findById(dishId).get();
        repository.delete(recipe);
    }


    public Recipe get(Integer id) {
        Optional<Recipe> recipe = repository.findById(id);
        if (recipe.isPresent()) {
            return recipe.get();
        } else {
            return null;
        }
    }

    public List<Recipe> findByKeyword(String keyword){
        return repository.findByKeyword(keyword);
    }

    public List<Recipe> getRandomRecipes(){
       List<Recipe> list = (List<Recipe>) repository.findAll();
        ArrayList<Recipe> selectedRecipes = new ArrayList<>();

        ThreadLocalRandom.current()
                .ints(0,list.size())
                .distinct().limit(7)
                .forEach(r -> selectedRecipes.add(list.get(r)));

        return selectedRecipes;


    }


    public List<Ingredient> ingredientList(List<Recipe> recipes) {
        List<Ingredient> ingredients = new ArrayList<>();

        for (Recipe recipe : recipes) {
            for (Ingredient ingredient : recipe.getIngredients()) {
                if (!ingredients.contains(ingredient)) {
                    ingredients.add(ingredient);
                }
            }
        }
        return ingredients;
    }


    public List<Recipe> getRandomVegRecipes(){
        List<Recipe> list = (List<Recipe>) repository.findAll();
        ArrayList<Recipe> selectedRecipes1 = new ArrayList<>();
        ArrayList<Recipe> selected1 = new ArrayList<>();

        for (Recipe r: list) {
            if(r.getType()==true){
                selected1.add(r);
            }

        }

        ThreadLocalRandom.current()
                .ints(0,selected1.size())
                .distinct().limit(7)
                .forEach(r -> selectedRecipes1.add(selected1.get(r)));

        return selectedRecipes1;


    }

    public List<Recipe> findAllOrderByLike() {

        return repository.findTop7ByOrderByLikeDesc();
    }
}
