package com.example.SpringEx.dao;

import com.example.SpringEx.model.Ingredient;
import org.springframework.data.repository.CrudRepository;

public interface IngredientRepository extends CrudRepository <Ingredient,Integer> {






}
