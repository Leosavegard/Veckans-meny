package com.example.SpringEx.model;

import java.util.List;
import java.util.Objects;


public class CreateRecipe {

    private Recipe recipe;
    private List<Ingredient> ingredients;
    private List<Boolean> selected;



    public Recipe getRecipe() {
        return recipe;
    }

    public void setRecipe(Recipe recipe) {
        this.recipe = recipe;
    }

    public List<Ingredient> getIngredients() {
        return ingredients;
    }

    public void setIngredients(List<Ingredient> ingredients) {
        this.ingredients = ingredients;
    }

    public List<Boolean> getSelected() {
        return selected;
    }

    public void setSelected(List<Boolean> selected) {
        this.selected = selected;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CreateRecipe)) return false;
        CreateRecipe that = (CreateRecipe) o;
        return Objects.equals(getRecipe(), that.getRecipe()) && Objects.equals(getIngredients(), that.getIngredients()) && Objects.equals(getSelected(), that.getSelected());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getRecipe(), getIngredients(), getSelected());
    }
}
