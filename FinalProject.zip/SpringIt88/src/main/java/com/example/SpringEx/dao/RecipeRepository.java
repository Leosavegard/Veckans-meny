package com.example.SpringEx.dao;

import com.example.SpringEx.model.Recipe;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface RecipeRepository extends CrudRepository<Recipe,Integer> {
    @Query(value = "SELECT r FROM Recipe r WHERE r.name like %:keyword%")
    List<Recipe> findByKeyword(@Param("keyword") String keyword);

    List<Recipe> findTop7ByOrderByLikeDesc();


}
