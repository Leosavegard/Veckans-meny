package com.example.SpringEx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringItApplicationTests {

    @Test
    void contextLoads() {
    }

}
